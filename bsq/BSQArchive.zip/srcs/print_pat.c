/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   print.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xzeng <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/08/28 22:24:13 by xzeng             #+#    #+#             */
/*   Updated: 2017/08/30 15:12:21 by xluo             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

void	ft_putline(char *str, int dim)
{
	int	i;

	i = 0;
	while (i <= dim)
	{
		ft_putchar(str[i]);
		i++;
	}
}

void	change_pat(t_max point, char feature, char **pat)
{
	int	i;
	int	j;
	int	s;

	s = point.size;
	i = point.x - s + 1;
	while (i <= point.x)
	{
		j = point.y - s + 1;
		while (j <= point.y)
		{
			pat[i][j] = feature;
			j++;
		}
		i++;
	}
}

void	print_pat(char **pat, int dim[], char features[])
{
	int		i;
	t_max	point;

	if (!pat)
	{
		ft_putstr("map error\n");
		return ;
	}
	i = 0;
	point = maxsqr_fast(pat, dim, features);
	change_pat(point, features[2], pat);
	while (i < dim[0])
	{
		ft_putline(pat[i], dim[1]);
		i++;
	}
	i = -1;
	while (++i < dim[0])
		free(pat[i]);
	free(pat);
}
