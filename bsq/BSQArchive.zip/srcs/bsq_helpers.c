/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   bsq_helpers.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xluo <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/08/29 14:45:07 by xluo              #+#    #+#             */
/*   Updated: 2017/08/30 17:35:13 by xluo             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

int		ft_eleisval(char fs[], char c)
{
	if (c != fs[0] && c != fs[1])
		return (0);
	return (1);
}

int		ft_fsisval(char *str, char fs[], int *i, int *row)
{
	char	*nm;
	int		pos;
	int		k;

	pos = -1;
	while (str[++(*i)] != '\n')
		pos++;
	if (pos < 3)
		return (0);
	fs[2] = str[pos];
	fs[1] = str[--pos];
	fs[0] = str[--pos];
	if (fs[0] == fs[1] || fs[1] == fs[2] || fs[0] == fs[2])
		return (0);
	nm = (char *)malloc(sizeof(char) * (pos + 2));
	k = -1;
	while (++k < pos)
		nm[k] = str[k];
	nm[++k] = '\0';
	*row = ft_atoi(nm);
	if (ft_nbrlen(*row) != (pos) || *row == 0)
		return (0);
	return (1);
}

void	ft_arrini(int ar[], int len, int value)
{
	int	i;

	i = -1;
	while (++i < len)
		ar[i] = value;
}

int		ft_mapchk(char *str, int dim[], char features[])
{
	int	i;
	int	tmp[2];

	i = -1;
	ft_arrini(dim, 2, 0);
	ft_arrini(tmp, 2, 0);
	if (!ft_fsisval(str, features, &i, &dim[0]))
		return (0);
	while (str[++i] != '\0')
	{
		(tmp[1])++;
		if (str[i] == '\n')
		{
			if (tmp[0] == 0)
				dim[1] = tmp[1] - 1;
			else if (dim[1] != (tmp[1] - 1))
				return (0);
			(tmp[0])++;
			tmp[1] = 0;
		}
		else if (!ft_eleisval(features, str[i]))
			return (0);
	}
	return ((dim[0] == tmp[0] && dim[1] != 0));
}

char	**ft_allopatt(char *info, int dim[])
{
	char	**pat;
	int		i[4];

	ft_arrini(i, 4, -1);
	pat = (char **)malloc(sizeof(char *) * dim[0]);
	while ((++(i[0])) < dim[0])
		pat[i[0]] = (char *)malloc(sizeof(char) * (dim[1] + 1));
	while (info[i[1]] != '\n')
		i[1]++;
	while (++(i[2]) < dim[0])
	{
		i[3] = -1;
		while (++(i[3]) <= dim[1])
			pat[i[2]][i[3]] = (info[++i[1]]);
	}
	return (pat);
}
