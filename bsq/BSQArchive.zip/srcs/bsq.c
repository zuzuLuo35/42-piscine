/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   bsq.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: xluo <marvin@42.fr>                        +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2017/08/28 10:56:41 by xluo              #+#    #+#             */
/*   Updated: 2017/08/30 17:05:31 by xluo             ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft.h"

char	*ft_getinput(int fd)
{
	char	*out;
	int		ret;
	char	buf[BUF_SIZE + 1];
	char	*tmp;
	int		t_len;

	if (fd == -1)
		return ("0\n");
	t_len = 0;
	out = (char *)malloc(10);
	*out = '\0';
	while ((ret = read(fd, buf, BUF_SIZE)) > 0)
	{
		tmp = ft_strcpy_allo(tmp, out);
		free(out);
		buf[ret] = '\0';
		t_len += ret;
		out = (char *)malloc(sizeof(char) * (t_len + 1));
		out = ft_strcat(out, tmp);
		out = ft_strcat(out, buf);
		free(tmp);
	}
	close(fd);
	return (out);
}

char	**ft_testpatt(int ac, char *filename, int dim[], char features[])
{
	int		fd;
	char	**pat;
	char	*info;

	if (ac == 1)
		info = ft_getinput(0);
	else
	{
		fd = open(filename, O_RDONLY);
		info = ft_getinput(fd);
	}
	if (!ft_mapchk(info, dim, features))
		pat = 0;
	else
		pat = ft_allopatt(info, dim);
	if (pat != 0)
		free(info);
	return (pat);
}

int		main(int ac, char **av)
{
	int		i;
	char	**pat;
	int		dim[2];
	char	features[4];

	i = 0;
	if (ac == 1)
	{
		pat = ft_testpatt(ac, "No file", dim, features);
		print_pat(pat, dim, features);
	}
	else
		while (++i < ac)
		{
			pat = ft_testpatt(ac, av[i], dim, features);
			print_pat(pat, dim, features);
		}
	return (0);
}
